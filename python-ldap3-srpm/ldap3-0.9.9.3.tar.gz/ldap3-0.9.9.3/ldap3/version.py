# THIS FILE IS AUTO-GENERATED. PLEASE DO NOT MODIFY# version file for ldap3
# generated on 2015-11-15 23:24:19.718253
# on system uname_result(system='Windows', node='GCNBHPW8', release='post2012Server', version='6.3.9600', machine='AMD64', processor='Intel64 Family 6 Model 58 Stepping 9, GenuineIntel')
# with Python 3.5.0 - ('v3.5.0:374f501f4567', 'Sep 13 2015 02:27:37') - MSC v.1900 64 bit (AMD64)
#
__version__ = '0.9.9.3'
__author__ = 'Giovanni Cannata'
__email__ = 'cannatag@gmail.com'
__url__ = 'https://github.com/cannatag/ldap3'
__description__ = 'A strictly RFC 4510 conforming LDAP V3 pure Python client. Same codebase for Python 2, Python3, PyPy and PyPy 3'
__status__ = 'development - beta'
__license__ = 'LGPL v3'
