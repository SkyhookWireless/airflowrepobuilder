==============================================
 kombu.utils.url
==============================================

.. contents::
    :local:
.. currentmodule:: kombu.utils.url

.. automodule:: kombu.utils.url
    :members:
    :undoc-members:
