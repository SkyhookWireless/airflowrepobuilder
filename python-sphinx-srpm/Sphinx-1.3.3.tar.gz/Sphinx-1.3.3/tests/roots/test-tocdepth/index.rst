test-tocdepth
=============

.. toctree::
   :numbered:

   foo
   bar
