Dedent
======

Literal Include
---------------

.. literalinclude:: literal.inc
   :language: python
   :lines: 10-11
   :dedent: 0

.. literalinclude:: literal.inc
   :language: python
   :lines: 10-11
   :dedent: 1

.. literalinclude:: literal.inc
   :language: python
   :lines: 10-11
   :dedent: 2

.. literalinclude:: literal.inc
   :language: python
   :lines: 10-11
   :dedent: 3

.. literalinclude:: literal.inc
   :language: python
   :lines: 10-11
   :dedent: 4

.. literalinclude:: literal.inc
   :language: python
   :lines: 10-11
   :dedent: 1000
