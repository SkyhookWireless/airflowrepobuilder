extensions = ['sphinx.ext.doctest']

project = 'test project for doctest'
master_doc = 'doctest.txt'
source_suffix = '.txt'
