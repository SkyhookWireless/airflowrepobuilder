# -*- coding: utf-8 -*-

html_theme = 'test-theme'
master_doc = 'index'

