:orphan:

sphinx-quickstart manual page
=============================

Synopsis
--------

**sphinx-quickstart**


Description
-----------

:program:`sphinx-quickstart` is an interactive tool that asks some questions
about your project and then generates a complete documentation directory and
sample Makefile to be used with :manpage:`sphinx-build(1)`.


See also
--------

:manpage:`sphinx-build(1)`


Author
------

Georg Brandl <georg@python.org>, Armin Ronacher <armin.ronacher@active-4.com> et
al.

This manual page was initially written by Mikhail Gusarov
<dottedmag@dottedmag.net>, for the Debian project.
