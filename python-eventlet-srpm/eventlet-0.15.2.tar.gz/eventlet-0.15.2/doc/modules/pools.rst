:mod:`pools` - Generic pools of resources 
==========================================

.. automodule:: eventlet.pools
	:members:
