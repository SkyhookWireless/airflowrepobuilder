#line 1 "example_c_file.c"


#line 1 "D:\eli\cpp_stuff\libc_include/stdio.h"

#line 19 "D:\eli\cpp_stuff\libc_include/stdio.h"


#line 25 "D:\eli\cpp_stuff\libc_include/stdio.h"




#line 1 "D:\eli\cpp_stuff\libc_include/_ansi.h"



#line 11 "D:\eli\cpp_stuff\libc_include/_ansi.h"




#line 1 "D:\eli\cpp_stuff\libc_include/newlib.h"

#line 3 "D:\eli\cpp_stuff\libc_include/newlib.h"
#line 16 "D:\eli\cpp_stuff\libc_include/_ansi.h"
#line 1 "D:\eli\cpp_stuff\libc_include/sys/config.h"



#line 1 "D:\eli\cpp_stuff\libc_include/machine/ieeefp.h"




#line 52 "D:\eli\cpp_stuff\libc_include/machine/ieeefp.h"



#line 58 "D:\eli\cpp_stuff\libc_include/machine/ieeefp.h"






















#line 83 "D:\eli\cpp_stuff\libc_include/machine/ieeefp.h"

#line 86 "D:\eli\cpp_stuff\libc_include/machine/ieeefp.h"

#line 89 "D:\eli\cpp_stuff\libc_include/machine/ieeefp.h"


#line 95 "D:\eli\cpp_stuff\libc_include/machine/ieeefp.h"











































































































































































































































#line 5 "D:\eli\cpp_stuff\libc_include/sys/config.h"





#line 11 "D:\eli\cpp_stuff\libc_include/sys/config.h"
































































































































#line 143 "D:\eli\cpp_stuff\libc_include/sys/config.h"













#line 157 "D:\eli\cpp_stuff\libc_include/sys/config.h"




































#line 195 "D:\eli\cpp_stuff\libc_include/sys/config.h"











#line 207 "D:\eli\cpp_stuff\libc_include/sys/config.h"







#line 17 "D:\eli\cpp_stuff\libc_include/_ansi.h"



#line 21 "D:\eli\cpp_stuff\libc_include/_ansi.h"















































































#line 30 "D:\eli\cpp_stuff\libc_include/stdio.h"




#line 1 "D:\eli\cpp_stuff\libc_include/stddef.h"

#line 19 "D:\eli\cpp_stuff\libc_include/stddef.h"


#line 26 "D:\eli\cpp_stuff\libc_include/stddef.h"


#line 30 "D:\eli\cpp_stuff\libc_include/stddef.h"

#line 35 "D:\eli\cpp_stuff\libc_include/stddef.h"


#line 39 "D:\eli\cpp_stuff\libc_include/stddef.h"

#line 42 "D:\eli\cpp_stuff\libc_include/stddef.h"










#line 53 "D:\eli\cpp_stuff\libc_include/stddef.h"


#line 56 "D:\eli\cpp_stuff\libc_include/stddef.h"









#line 67 "D:\eli\cpp_stuff\libc_include/stddef.h"








#line 76 "D:\eli\cpp_stuff\libc_include/stddef.h"





















#line 98 "D:\eli\cpp_stuff\libc_include/stddef.h"





#line 108 "D:\eli\cpp_stuff\libc_include/stddef.h"














#line 126 "D:\eli\cpp_stuff\libc_include/stddef.h"




#line 131 "D:\eli\cpp_stuff\libc_include/stddef.h"






































#line 170 "D:\eli\cpp_stuff\libc_include/stddef.h"











































typedef long unsigned int size_t;


























#line 243 "D:\eli\cpp_stuff\libc_include/stddef.h"


#line 246 "D:\eli\cpp_stuff\libc_include/stddef.h"



































#line 290 "D:\eli\cpp_stuff\libc_include/stddef.h"









#line 302 "D:\eli\cpp_stuff\libc_include/stddef.h"






#line 310 "D:\eli\cpp_stuff\libc_include/stddef.h"


















































#line 361 "D:\eli\cpp_stuff\libc_include/stddef.h"



#line 365 "D:\eli\cpp_stuff\libc_include/stddef.h"




















































#line 418 "D:\eli\cpp_stuff\libc_include/stddef.h"

#line 422 "D:\eli\cpp_stuff\libc_include/stddef.h"




#line 427 "D:\eli\cpp_stuff\libc_include/stddef.h"
#line 35 "D:\eli\cpp_stuff\libc_include/stdio.h"


#line 1 "D:\eli\cpp_stuff\libc_include/stdarg.h"

#line 19 "D:\eli\cpp_stuff\libc_include/stdarg.h"


#line 26 "D:\eli\cpp_stuff\libc_include/stdarg.h"


#line 30 "D:\eli\cpp_stuff\libc_include/stdarg.h"














typedef char* __builtin_va_list;
typedef __builtin_va_list __gnuc_va_list;



#line 50 "D:\eli\cpp_stuff\libc_include/stdarg.h"












#line 66 "D:\eli\cpp_stuff\libc_include/stdarg.h"











#line 80 "D:\eli\cpp_stuff\libc_include/stdarg.h"















#line 98 "D:\eli\cpp_stuff\libc_include/stdarg.h"







































#line 38 "D:\eli\cpp_stuff\libc_include/stdio.h"


#line 44 "D:\eli\cpp_stuff\libc_include/stdio.h"

#line 1 "D:\eli\cpp_stuff\libc_include/sys/reent.h"



#line 6 "D:\eli\cpp_stuff\libc_include/sys/reent.h"







#line 1 "D:\eli\cpp_stuff\libc_include/_ansi.h"



#line 11 "D:\eli\cpp_stuff\libc_include/_ansi.h"









#line 21 "D:\eli\cpp_stuff\libc_include/_ansi.h"















































































#line 14 "D:\eli\cpp_stuff\libc_include/sys/reent.h"
#line 1 "D:\eli\cpp_stuff\libc_include/sys/_types.h"



#line 8 "D:\eli\cpp_stuff\libc_include/sys/_types.h"




#line 1 "D:\eli\cpp_stuff\libc_include/machine/_types.h"

#line 4 "D:\eli\cpp_stuff\libc_include/machine/_types.h"



#line 1 "D:\eli\cpp_stuff\libc_include/machine/_default_types.h"

#line 4 "D:\eli\cpp_stuff\libc_include/machine/_default_types.h"









#line 15 "D:\eli\cpp_stuff\libc_include/machine/_default_types.h"

#line 17 "D:\eli\cpp_stuff\libc_include/machine/_default_types.h"





#line 1 "D:\eli\cpp_stuff\libc_include/limits.h"



#line 1 "D:\eli\cpp_stuff\libc_include/newlib.h"

#line 3 "D:\eli\cpp_stuff\libc_include/newlib.h"
#line 5 "D:\eli\cpp_stuff\libc_include/limits.h"













#line 19 "D:\eli\cpp_stuff\libc_include/limits.h"





#line 1 "D:\eli\cpp_stuff\libc_include/sys/config.h"









#line 11 "D:\eli\cpp_stuff\libc_include/sys/config.h"
































































































































#line 143 "D:\eli\cpp_stuff\libc_include/sys/config.h"













#line 157 "D:\eli\cpp_stuff\libc_include/sys/config.h"




































#line 195 "D:\eli\cpp_stuff\libc_include/sys/config.h"











#line 207 "D:\eli\cpp_stuff\libc_include/sys/config.h"







#line 25 "D:\eli\cpp_stuff\libc_include/limits.h"





















































#line 79 "D:\eli\cpp_stuff\libc_include/limits.h"

















































#line 23 "D:\eli\cpp_stuff\libc_include/machine/_default_types.h"



typedef signed char __int8_t ;
typedef unsigned char __uint8_t ;








typedef signed short __int16_t;
typedef unsigned short __uint16_t;








typedef __int16_t __int_least16_t;
typedef __uint16_t __uint_least16_t;










typedef signed int __int32_t;
typedef unsigned int __uint32_t;
















typedef __int32_t __int_least32_t;
typedef __uint32_t __uint_least32_t;












































#line 8 "D:\eli\cpp_stuff\libc_include/machine/_types.h"

#line 13 "D:\eli\cpp_stuff\libc_include/sys/_types.h"
#line 1 "D:\eli\cpp_stuff\libc_include/sys/lock.h"





typedef int _LOCK_T;
typedef int _LOCK_RECURSIVE_T;















#line 14 "D:\eli\cpp_stuff\libc_include/sys/_types.h"


typedef long _off_t;







typedef short __dev_t;




typedef unsigned short __uid_t;


typedef unsigned short __gid_t;



 typedef long long _off64_t;



#line 43 "D:\eli\cpp_stuff\libc_include/sys/_types.h"

typedef long _fpos_t;











typedef int _ssize_t;






#line 1 "D:\eli\cpp_stuff\libc_include/stddef.h"

#line 19 "D:\eli\cpp_stuff\libc_include/stddef.h"


#line 26 "D:\eli\cpp_stuff\libc_include/stddef.h"


#line 30 "D:\eli\cpp_stuff\libc_include/stddef.h"

#line 35 "D:\eli\cpp_stuff\libc_include/stddef.h"


#line 39 "D:\eli\cpp_stuff\libc_include/stddef.h"

#line 42 "D:\eli\cpp_stuff\libc_include/stddef.h"










#line 53 "D:\eli\cpp_stuff\libc_include/stddef.h"


#line 56 "D:\eli\cpp_stuff\libc_include/stddef.h"









#line 67 "D:\eli\cpp_stuff\libc_include/stddef.h"








#line 76 "D:\eli\cpp_stuff\libc_include/stddef.h"





















#line 98 "D:\eli\cpp_stuff\libc_include/stddef.h"





#line 108 "D:\eli\cpp_stuff\libc_include/stddef.h"














#line 126 "D:\eli\cpp_stuff\libc_include/stddef.h"




#line 131 "D:\eli\cpp_stuff\libc_include/stddef.h"






































#line 170 "D:\eli\cpp_stuff\libc_include/stddef.h"






































































#line 243 "D:\eli\cpp_stuff\libc_include/stddef.h"


#line 246 "D:\eli\cpp_stuff\libc_include/stddef.h"



































#line 290 "D:\eli\cpp_stuff\libc_include/stddef.h"









#line 302 "D:\eli\cpp_stuff\libc_include/stddef.h"






#line 310 "D:\eli\cpp_stuff\libc_include/stddef.h"












































typedef unsigned int wint_t;





#line 361 "D:\eli\cpp_stuff\libc_include/stddef.h"



#line 365 "D:\eli\cpp_stuff\libc_include/stddef.h"




















































#line 418 "D:\eli\cpp_stuff\libc_include/stddef.h"

#line 422 "D:\eli\cpp_stuff\libc_include/stddef.h"




#line 427 "D:\eli\cpp_stuff\libc_include/stddef.h"
#line 64 "D:\eli\cpp_stuff\libc_include/sys/_types.h"



typedef struct
{
  int __count;
  union
  {
    wint_t __wch;
    unsigned char __wchb[4];
  } __value;
} _mbstate_t;



typedef _LOCK_RECURSIVE_T _flock_t;




typedef void *_iconv_t;



#line 15 "D:\eli\cpp_stuff\libc_include/sys/reent.h"






typedef unsigned long __ULong;















struct _reent;


#line 43 "D:\eli\cpp_stuff\libc_include/sys/reent.h"

struct _Bigint
{
  struct _Bigint *_next;
  int _k, _maxwds, _sign, _wds;
  __ULong _x[1];
};


struct __tm
{
  int   __tm_sec;
  int   __tm_min;
  int   __tm_hour;
  int   __tm_mday;
  int   __tm_mon;
  int   __tm_year;
  int   __tm_wday;
  int   __tm_yday;
  int   __tm_isdst;
};


#line 68 "D:\eli\cpp_stuff\libc_include/sys/reent.h"



struct _on_exit_args {
	void *  _fnargs[32];
	void *	_dso_handle[32];

	__ULong _fntypes;
#line 77 "D:\eli\cpp_stuff\libc_include/sys/reent.h"

	__ULong _is_cxa;
};









struct _atexit {
	struct	_atexit *_next;
	int	_ind;

	void	(*_fns[32])(void);
        struct _on_exit_args _on_exit_args;
};



#line 104 "D:\eli\cpp_stuff\libc_include/sys/reent.h"

struct __sbuf {
	unsigned char *_base;
	int	_size;
};


#line 134 "D:\eli\cpp_stuff\libc_include/sys/reent.h"



#line 141 "D:\eli\cpp_stuff\libc_include/sys/reent.h"

















struct __sFILE {
  unsigned char *_p;
  int	_r;
  int	_w;
  short	_flags;
  short	_file;
  struct __sbuf _bf;
  int	_lbfsize;






 char * _cookie;

 int(*_read)();
#line 176 "D:\eli\cpp_stuff\libc_include/sys/reent.h"
 int(*_write)();
#line 178 "D:\eli\cpp_stuff\libc_include/sys/reent.h"
  _fpos_t(*_seek)();
  int(*_close)();


  struct __sbuf _ub;
  unsigned char *_up;
  int	_ur;


  unsigned char _ubuf[3];
  unsigned char _nbuf[1];


  struct __sbuf _lb;


  int	_blksize;
  int	_offset;


  struct _reent *_data;



  _flock_t _lock;

};






















































typedef struct __sFILE   __FILE;



struct _glue
{
  struct _glue *_next;
  int _niobs;
  __FILE *_iobs;
};


#line 284 "D:\eli\cpp_stuff\libc_include/sys/reent.h"







struct _rand48 {
  unsigned short _seed[3];
  unsigned short _mult[3];
  unsigned short _add;




};







#line 313 "D:\eli\cpp_stuff\libc_include/sys/reent.h"






























#line 344 "D:\eli\cpp_stuff\libc_include/sys/reent.h"




#line 350 "D:\eli\cpp_stuff\libc_include/sys/reent.h"













































#line 420 "D:\eli\cpp_stuff\libc_include/sys/reent.h"


#line 452 "D:\eli\cpp_stuff\libc_include/sys/reent.h"















#line 474 "D:\eli\cpp_stuff\libc_include/sys/reent.h"


#line 478 "D:\eli\cpp_stuff\libc_include/sys/reent.h"


#line 482 "D:\eli\cpp_stuff\libc_include/sys/reent.h"



#line 494 "D:\eli\cpp_stuff\libc_include/sys/reent.h"

#line 496 "D:\eli\cpp_stuff\libc_include/sys/reent.h"


#line 503 "D:\eli\cpp_stuff\libc_include/sys/reent.h"

#line 505 "D:\eli\cpp_stuff\libc_include/sys/reent.h"


#line 508 "D:\eli\cpp_stuff\libc_include/sys/reent.h"


#line 531 "D:\eli\cpp_stuff\libc_include/sys/reent.h"

#line 533 "D:\eli\cpp_stuff\libc_include/sys/reent.h"


#line 536 "D:\eli\cpp_stuff\libc_include/sys/reent.h"




























struct _reent
{
  int _errno;


#line 571 "D:\eli\cpp_stuff\libc_include/sys/reent.h"
  __FILE *_stdin, *_stdout, *_stderr;

  int  _inc;
  char _emergency[25];

  int _current_category;
 char *_current_locale;

  int __sdidinit;

  void(*__cleanup)();


  struct _Bigint *_result;
  int _result_k;
  struct _Bigint *_p5s;
  struct _Bigint **_freelist;


  int _cvtlen;
  char *_cvtbuf;

  union
    {
      struct
        {
          unsigned int _unused_rand;
          char * _strtok_last;
          char _asctime_buf[26];
          struct __tm _localtime_buf;
          int _gamma_signgam;
 unsigned long long _rand_next;
          struct _rand48 _r48;
          _mbstate_t _mblen_state;
          _mbstate_t _mbtowc_state;
          _mbstate_t _wctomb_state;
          char _l64a_buf[8];
          char _signal_buf[24];
          int _getdate_err;
          _mbstate_t _mbrlen_state;
          _mbstate_t _mbrtowc_state;
          _mbstate_t _mbsrtowcs_state;
          _mbstate_t _wcrtomb_state;
          _mbstate_t _wcsrtombs_state;
        } _reent;

#line 619 "D:\eli\cpp_stuff\libc_include/sys/reent.h"
      struct
        {

          unsigned char * _nextf[30];
          unsigned int _nmalloc[30];
        } _unused;
    } _new;


  struct _atexit *_atexit;
  struct _atexit _atexit0;


  void (**(_sig_func))(int);


#line 637 "D:\eli\cpp_stuff\libc_include/sys/reent.h"
  struct _glue __sglue;
  __FILE __sf[3];
};


#line 689 "D:\eli\cpp_stuff\libc_include/sys/reent.h"


#line 751 "D:\eli\cpp_stuff\libc_include/sys/reent.h"





































#line 791 "D:\eli\cpp_stuff\libc_include/sys/reent.h"





extern struct _reent *_impure_ptr;
extern struct _reent * _global_impure_ptr;

void _reclaim_reent();






















#line 46 "D:\eli\cpp_stuff\libc_include/stdio.h"
#line 1 "D:\eli\cpp_stuff\libc_include/sys/types.h"

#line 17 "D:\eli\cpp_stuff\libc_include/sys/types.h"



#line 1 "D:\eli\cpp_stuff\libc_include/_ansi.h"



#line 11 "D:\eli\cpp_stuff\libc_include/_ansi.h"









#line 21 "D:\eli\cpp_stuff\libc_include/_ansi.h"















































































#line 21 "D:\eli\cpp_stuff\libc_include/sys/types.h"




#line 1 "D:\eli\cpp_stuff\libc_include/machine/_types.h"

#line 4 "D:\eli\cpp_stuff\libc_include/machine/_types.h"





#line 26 "D:\eli\cpp_stuff\libc_include/sys/types.h"



#line 33 "D:\eli\cpp_stuff\libc_include/sys/types.h"




























#line 1 "D:\eli\cpp_stuff\libc_include/sys/_types.h"



#line 8 "D:\eli\cpp_stuff\libc_include/sys/_types.h"
































#line 43 "D:\eli\cpp_stuff\libc_include/sys/_types.h"













































#line 62 "D:\eli\cpp_stuff\libc_include/sys/types.h"







#line 1 "D:\eli\cpp_stuff\libc_include/stddef.h"

#line 19 "D:\eli\cpp_stuff\libc_include/stddef.h"


#line 26 "D:\eli\cpp_stuff\libc_include/stddef.h"


#line 30 "D:\eli\cpp_stuff\libc_include/stddef.h"

#line 35 "D:\eli\cpp_stuff\libc_include/stddef.h"


#line 39 "D:\eli\cpp_stuff\libc_include/stddef.h"

#line 42 "D:\eli\cpp_stuff\libc_include/stddef.h"










#line 53 "D:\eli\cpp_stuff\libc_include/stddef.h"


#line 56 "D:\eli\cpp_stuff\libc_include/stddef.h"









#line 67 "D:\eli\cpp_stuff\libc_include/stddef.h"








#line 76 "D:\eli\cpp_stuff\libc_include/stddef.h"





















#line 98 "D:\eli\cpp_stuff\libc_include/stddef.h"





#line 108 "D:\eli\cpp_stuff\libc_include/stddef.h"














#line 126 "D:\eli\cpp_stuff\libc_include/stddef.h"




#line 131 "D:\eli\cpp_stuff\libc_include/stddef.h"




















typedef long int ptrdiff_t;

















#line 170 "D:\eli\cpp_stuff\libc_include/stddef.h"






































































#line 243 "D:\eli\cpp_stuff\libc_include/stddef.h"


#line 246 "D:\eli\cpp_stuff\libc_include/stddef.h"



































#line 290 "D:\eli\cpp_stuff\libc_include/stddef.h"









#line 302 "D:\eli\cpp_stuff\libc_include/stddef.h"






#line 310 "D:\eli\cpp_stuff\libc_include/stddef.h"















typedef int wchar_t;


































#line 361 "D:\eli\cpp_stuff\libc_include/stddef.h"



#line 365 "D:\eli\cpp_stuff\libc_include/stddef.h"




















































#line 418 "D:\eli\cpp_stuff\libc_include/stddef.h"

#line 422 "D:\eli\cpp_stuff\libc_include/stddef.h"




#line 427 "D:\eli\cpp_stuff\libc_include/stddef.h"
#line 70 "D:\eli\cpp_stuff\libc_include/sys/types.h"
#line 1 "D:\eli\cpp_stuff\libc_include/machine/types.h"




#line 9 "D:\eli\cpp_stuff\libc_include/machine/types.h"










typedef long int __off_t;
typedef int __pid_t;



typedef long int __loff_t;






#line 71 "D:\eli\cpp_stuff\libc_include/sys/types.h"


#line 79 "D:\eli\cpp_stuff\libc_include/sys/types.h"













typedef	unsigned char	u_char;
typedef	unsigned short	u_short;
typedef	unsigned int	u_int;
typedef	unsigned long	u_long;



typedef	unsigned short	ushort;
typedef	unsigned int	uint;



typedef unsigned long clock_t;




typedef long time_t;




struct timespec {
  time_t  tv_sec;
  long    tv_nsec;
};

struct itimerspec {
  struct timespec  it_interval;
  struct timespec  it_value;
};


typedef	long	daddr_t;
typedef	char *	caddr_t;



#line 131 "D:\eli\cpp_stuff\libc_include/sys/types.h"


typedef	unsigned short	ino_t;





















#line 160 "D:\eli\cpp_stuff\libc_include/sys/types.h"


typedef _off_t	off_t;
typedef __dev_t dev_t;
typedef __uid_t uid_t;
typedef __gid_t gid_t;


typedef int pid_t;

typedef	long key_t;

typedef _ssize_t ssize_t;













typedef unsigned int mode_t;




typedef unsigned short nlink_t;


#line 200 "D:\eli\cpp_stuff\libc_include/sys/types.h"




#line 209 "D:\eli\cpp_stuff\libc_include/sys/types.h"




typedef	long	fd_mask;






#line 221 "D:\eli\cpp_stuff\libc_include/sys/types.h"
typedef	struct _types_fd_set {
	fd_mask	fds_bits[(((64)+(((sizeof (fd_mask) * 8))-1))/((sizeof (fd_mask) * 8)))];
} _types_fd_set;







#line 236 "D:\eli\cpp_stuff\libc_include/sys/types.h"








typedef unsigned long clockid_t;




typedef unsigned long timer_t;



typedef unsigned long useconds_t;
typedef long suseconds_t;

#line 1 "D:\eli\cpp_stuff\libc_include/sys/features.h"

#line 20 "D:\eli\cpp_stuff\libc_include/sys/features.h"

































































































































































#line 257 "D:\eli\cpp_stuff\libc_include/sys/types.h"



#line 266 "D:\eli\cpp_stuff\libc_include/sys/types.h"





#line 273 "D:\eli\cpp_stuff\libc_include/sys/types.h"

































































































































#line 47 "D:\eli\cpp_stuff\libc_include/stdio.h"



typedef __FILE FILE;








typedef _fpos_t fpos_t;





#line 1 "D:\eli\cpp_stuff\libc_include/sys/stdio.h"



#line 1 "D:\eli\cpp_stuff\libc_include/sys/lock.h"






















#line 5 "D:\eli\cpp_stuff\libc_include/sys/stdio.h"
#line 1 "D:\eli\cpp_stuff\libc_include/sys/reent.h"



#line 6 "D:\eli\cpp_stuff\libc_include/sys/reent.h"


































#line 43 "D:\eli\cpp_stuff\libc_include/sys/reent.h"























#line 68 "D:\eli\cpp_stuff\libc_include/sys/reent.h"








#line 77 "D:\eli\cpp_stuff\libc_include/sys/reent.h"






















#line 104 "D:\eli\cpp_stuff\libc_include/sys/reent.h"







#line 134 "D:\eli\cpp_stuff\libc_include/sys/reent.h"



#line 141 "D:\eli\cpp_stuff\libc_include/sys/reent.h"


































































































































#line 284 "D:\eli\cpp_stuff\libc_include/sys/reent.h"























#line 313 "D:\eli\cpp_stuff\libc_include/sys/reent.h"






























#line 344 "D:\eli\cpp_stuff\libc_include/sys/reent.h"




#line 350 "D:\eli\cpp_stuff\libc_include/sys/reent.h"













































#line 420 "D:\eli\cpp_stuff\libc_include/sys/reent.h"


#line 452 "D:\eli\cpp_stuff\libc_include/sys/reent.h"















#line 474 "D:\eli\cpp_stuff\libc_include/sys/reent.h"


#line 478 "D:\eli\cpp_stuff\libc_include/sys/reent.h"


#line 482 "D:\eli\cpp_stuff\libc_include/sys/reent.h"



#line 494 "D:\eli\cpp_stuff\libc_include/sys/reent.h"

#line 496 "D:\eli\cpp_stuff\libc_include/sys/reent.h"


#line 503 "D:\eli\cpp_stuff\libc_include/sys/reent.h"

#line 505 "D:\eli\cpp_stuff\libc_include/sys/reent.h"


#line 508 "D:\eli\cpp_stuff\libc_include/sys/reent.h"


#line 531 "D:\eli\cpp_stuff\libc_include/sys/reent.h"

#line 533 "D:\eli\cpp_stuff\libc_include/sys/reent.h"


#line 536 "D:\eli\cpp_stuff\libc_include/sys/reent.h"

































#line 571 "D:\eli\cpp_stuff\libc_include/sys/reent.h"














































#line 619 "D:\eli\cpp_stuff\libc_include/sys/reent.h"
















#line 637 "D:\eli\cpp_stuff\libc_include/sys/reent.h"





#line 689 "D:\eli\cpp_stuff\libc_include/sys/reent.h"


#line 751 "D:\eli\cpp_stuff\libc_include/sys/reent.h"





































#line 791 "D:\eli\cpp_stuff\libc_include/sys/reent.h"































#line 6 "D:\eli\cpp_stuff\libc_include/sys/stdio.h"


#line 11 "D:\eli\cpp_stuff\libc_include/sys/stdio.h"

















#line 66 "D:\eli\cpp_stuff\libc_include/stdio.h"






















#line 96 "D:\eli\cpp_stuff\libc_include/stdio.h"

































































#line 163 "D:\eli\cpp_stuff\libc_include/stdio.h"







FILE * tmpfile();
char * tmpnam();
int fclose();
int fflush();
FILE * freopen();
void setbuf();
int setvbuf();
int fprintf();
#line 179 "D:\eli\cpp_stuff\libc_include/stdio.h"
int fscanf();
#line 181 "D:\eli\cpp_stuff\libc_include/stdio.h"
int printf();
#line 183 "D:\eli\cpp_stuff\libc_include/stdio.h"
int scanf();
#line 185 "D:\eli\cpp_stuff\libc_include/stdio.h"
int sscanf();
#line 187 "D:\eli\cpp_stuff\libc_include/stdio.h"
int vfprintf();
#line 189 "D:\eli\cpp_stuff\libc_include/stdio.h"
int vprintf();
#line 191 "D:\eli\cpp_stuff\libc_include/stdio.h"
int vsprintf();
#line 193 "D:\eli\cpp_stuff\libc_include/stdio.h"
int fgetc();
char * fgets();
int fputc();
int fputs();
int getc();
int getchar();
char * gets();
int putc();
int putchar();
int puts();
int ungetc();
size_t fread();
size_t fwrite();



int fgetpos();

int fseek();



int fsetpos();

long ftell();
void rewind();
void clearerr();
int feof();
int ferror();
void perror();

FILE * fopen();
int sprintf();
#line 227 "D:\eli\cpp_stuff\libc_include/stdio.h"
int remove();
int rename();






int fseeko();
off_t ftello();


int asiprintf();
#line 241 "D:\eli\cpp_stuff\libc_include/stdio.h"
char * asniprintf();
#line 243 "D:\eli\cpp_stuff\libc_include/stdio.h"
char * asnprintf();
#line 245 "D:\eli\cpp_stuff\libc_include/stdio.h"
int asprintf();
#line 247 "D:\eli\cpp_stuff\libc_include/stdio.h"

int diprintf();
#line 250 "D:\eli\cpp_stuff\libc_include/stdio.h"

int fcloseall();
int fiprintf();
#line 254 "D:\eli\cpp_stuff\libc_include/stdio.h"
int fiscanf();
#line 256 "D:\eli\cpp_stuff\libc_include/stdio.h"
int iprintf();
#line 258 "D:\eli\cpp_stuff\libc_include/stdio.h"
int iscanf();
#line 260 "D:\eli\cpp_stuff\libc_include/stdio.h"
int siprintf();
#line 262 "D:\eli\cpp_stuff\libc_include/stdio.h"
int siscanf();
#line 264 "D:\eli\cpp_stuff\libc_include/stdio.h"
int snprintf();
#line 266 "D:\eli\cpp_stuff\libc_include/stdio.h"
int sniprintf();
#line 268 "D:\eli\cpp_stuff\libc_include/stdio.h"
char * tempnam();
int vasiprintf();
#line 271 "D:\eli\cpp_stuff\libc_include/stdio.h"
char * vasniprintf();
#line 273 "D:\eli\cpp_stuff\libc_include/stdio.h"
char * vasnprintf();
#line 275 "D:\eli\cpp_stuff\libc_include/stdio.h"
int vasprintf();
#line 277 "D:\eli\cpp_stuff\libc_include/stdio.h"
int vdiprintf();
#line 279 "D:\eli\cpp_stuff\libc_include/stdio.h"
int vfiprintf();
#line 281 "D:\eli\cpp_stuff\libc_include/stdio.h"
int vfiscanf();
#line 283 "D:\eli\cpp_stuff\libc_include/stdio.h"
int vfscanf();
#line 285 "D:\eli\cpp_stuff\libc_include/stdio.h"
int viprintf();
#line 287 "D:\eli\cpp_stuff\libc_include/stdio.h"
int viscanf();
#line 289 "D:\eli\cpp_stuff\libc_include/stdio.h"
int vscanf();
#line 291 "D:\eli\cpp_stuff\libc_include/stdio.h"
int vsiprintf();
#line 293 "D:\eli\cpp_stuff\libc_include/stdio.h"
int vsiscanf();
#line 295 "D:\eli\cpp_stuff\libc_include/stdio.h"
int vsniprintf();
#line 297 "D:\eli\cpp_stuff\libc_include/stdio.h"
int vsnprintf();
#line 299 "D:\eli\cpp_stuff\libc_include/stdio.h"
int vsscanf();
#line 301 "D:\eli\cpp_stuff\libc_include/stdio.h"




#line 307 "D:\eli\cpp_stuff\libc_include/stdio.h"



FILE * fdopen();

int fileno();
int getw();
int pclose();
FILE * popen();
int putw();
void setbuffer();
int setlinebuf();
int getc_unlocked();
int getchar_unlocked();
void flockfile();
int ftrylockfile();
void funlockfile();
int putc_unlocked();
int putchar_unlocked();



#line 331 "D:\eli\cpp_stuff\libc_include/stdio.h"




int dprintf();
#line 337 "D:\eli\cpp_stuff\libc_include/stdio.h"

FILE * fmemopen();


FILE * open_memstream();

int vdprintf();
#line 345 "D:\eli\cpp_stuff\libc_include/stdio.h"




#line 351 "D:\eli\cpp_stuff\libc_include/stdio.h"

int _asiprintf_r();
#line 354 "D:\eli\cpp_stuff\libc_include/stdio.h"
char * _asniprintf_r();
#line 356 "D:\eli\cpp_stuff\libc_include/stdio.h"
char * _asnprintf_r();
#line 358 "D:\eli\cpp_stuff\libc_include/stdio.h"
int _asprintf_r();
#line 360 "D:\eli\cpp_stuff\libc_include/stdio.h"
int _diprintf_r();
#line 362 "D:\eli\cpp_stuff\libc_include/stdio.h"
int _dprintf_r();
#line 364 "D:\eli\cpp_stuff\libc_include/stdio.h"
int _fclose_r();
int _fcloseall_r();
FILE * _fdopen_r();
int _fflush_r();
char * _fgets_r();
int _fiprintf_r();
#line 371 "D:\eli\cpp_stuff\libc_include/stdio.h"
int _fiscanf_r();
#line 373 "D:\eli\cpp_stuff\libc_include/stdio.h"
FILE * _fmemopen_r();
FILE * _fopen_r();
int _fprintf_r();
#line 377 "D:\eli\cpp_stuff\libc_include/stdio.h"
int _fputc_r();
int _fputs_r();
size_t _fread_r();
int _fscanf_r();
#line 382 "D:\eli\cpp_stuff\libc_include/stdio.h"
int _fseek_r();
long _ftell_r();
size_t _fwrite_r();
int _getc_r();
int _getc_unlocked_r();
int _getchar_r();
int _getchar_unlocked_r();
char * _gets_r();
int _iprintf_r();
#line 392 "D:\eli\cpp_stuff\libc_include/stdio.h"
int _iscanf_r();
#line 394 "D:\eli\cpp_stuff\libc_include/stdio.h"
int _mkstemp_r();
char * _mktemp_r();
FILE * _open_memstream_r();
void _perror_r();
int _printf_r();
#line 400 "D:\eli\cpp_stuff\libc_include/stdio.h"
int _putc_r();
int _putc_unlocked_r();
int _putchar_unlocked_r();
int _putchar_r();
int _puts_r();
int _remove_r();
int _rename_r();
#line 408 "D:\eli\cpp_stuff\libc_include/stdio.h"
int _scanf_r();
#line 410 "D:\eli\cpp_stuff\libc_include/stdio.h"
int _siprintf_r();
#line 412 "D:\eli\cpp_stuff\libc_include/stdio.h"
int _siscanf_r();
#line 414 "D:\eli\cpp_stuff\libc_include/stdio.h"
int _sniprintf_r();
#line 416 "D:\eli\cpp_stuff\libc_include/stdio.h"
int _snprintf_r();
#line 418 "D:\eli\cpp_stuff\libc_include/stdio.h"
int _sprintf_r();
#line 420 "D:\eli\cpp_stuff\libc_include/stdio.h"
int _sscanf_r();
#line 422 "D:\eli\cpp_stuff\libc_include/stdio.h"
char * _tempnam_r();
FILE * _tmpfile_r();
char * _tmpnam_r();
int _ungetc_r();
int _vasiprintf_r();
#line 428 "D:\eli\cpp_stuff\libc_include/stdio.h"
char * _vasniprintf_r();
#line 430 "D:\eli\cpp_stuff\libc_include/stdio.h"
char * _vasnprintf_r();
#line 432 "D:\eli\cpp_stuff\libc_include/stdio.h"
int _vasprintf_r();
#line 434 "D:\eli\cpp_stuff\libc_include/stdio.h"
int _vdiprintf_r();
#line 436 "D:\eli\cpp_stuff\libc_include/stdio.h"
int _vdprintf_r();
#line 438 "D:\eli\cpp_stuff\libc_include/stdio.h"
int _vfiprintf_r();
#line 440 "D:\eli\cpp_stuff\libc_include/stdio.h"
int _vfiscanf_r();
#line 442 "D:\eli\cpp_stuff\libc_include/stdio.h"
int _vfprintf_r();
#line 444 "D:\eli\cpp_stuff\libc_include/stdio.h"
int _vfscanf_r();
#line 446 "D:\eli\cpp_stuff\libc_include/stdio.h"
int _viprintf_r();
#line 448 "D:\eli\cpp_stuff\libc_include/stdio.h"
int _viscanf_r();
#line 450 "D:\eli\cpp_stuff\libc_include/stdio.h"
int _vprintf_r();
#line 452 "D:\eli\cpp_stuff\libc_include/stdio.h"
int _vscanf_r();
#line 454 "D:\eli\cpp_stuff\libc_include/stdio.h"
int _vsiprintf_r();
#line 456 "D:\eli\cpp_stuff\libc_include/stdio.h"
int _vsiscanf_r();
#line 458 "D:\eli\cpp_stuff\libc_include/stdio.h"
int _vsniprintf_r();
#line 460 "D:\eli\cpp_stuff\libc_include/stdio.h"
int _vsnprintf_r();
#line 462 "D:\eli\cpp_stuff\libc_include/stdio.h"
int _vsprintf_r();
#line 464 "D:\eli\cpp_stuff\libc_include/stdio.h"
int _vsscanf_r();
#line 466 "D:\eli\cpp_stuff\libc_include/stdio.h"

ssize_t __getdelim();
ssize_t __getline();






















#line 493 "D:\eli\cpp_stuff\libc_include/stdio.h"

int __srget_r();
int __swbuf_r();


#line 500 "D:\eli\cpp_stuff\libc_include/stdio.h"









FILE	* funopen();
#line 514 "D:\eli\cpp_stuff\libc_include/stdio.h"



#line 518 "D:\eli\cpp_stuff\libc_include/stdio.h"

#line 520 "D:\eli\cpp_stuff\libc_include/stdio.h"

typedef ssize_t cookie_read_function_t(void *__cookie, char *__buf, size_t __n);
typedef ssize_t cookie_write_function_t(void *__cookie, const char *__buf,
					size_t __n);




typedef int cookie_seek_function_t(void *__cookie, off_t *__off, int __whence);

typedef int cookie_close_function_t(void *__cookie);
typedef struct
{

#line 535 "D:\eli\cpp_stuff\libc_include/stdio.h"
  cookie_read_function_t  *read;
  cookie_write_function_t *write;
  cookie_seek_function_t  *seek;
  cookie_close_function_t *close;
} cookie_io_functions_t;
FILE * fopencookie();
#line 542 "D:\eli\cpp_stuff\libc_include/stdio.h"




#line 549 "D:\eli\cpp_stuff\libc_include/stdio.h"




#line 574 "D:\eli\cpp_stuff\libc_include/stdio.h"





#line 580 "D:\eli\cpp_stuff\libc_include/stdio.h"






















#line 603 "D:\eli\cpp_stuff\libc_include/stdio.h"








#line 613 "D:\eli\cpp_stuff\libc_include/stdio.h"

#line 621 "D:\eli\cpp_stuff\libc_include/stdio.h"


#line 626 "D:\eli\cpp_stuff\libc_include/stdio.h"






























#line 657 "D:\eli\cpp_stuff\libc_include/stdio.h"















#line 4 "example_c_file.c"

#line 8 "example_c_file.c"

char tav = 'b';
char maav = L"'guruguru\n";
char* moral = "ain't I \\\"\\\t\" a nice string?\"\"";
char* comment_inside = "but you will /* see it */!!!!";
char* i_have_newlines = "line one\nline two\nline three";

int main()
{
    auto char* multi = "a multi";
}





