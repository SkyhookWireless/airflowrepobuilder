VERSION = "2.7.2"


def version():
    return VERSION
