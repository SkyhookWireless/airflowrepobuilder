=============================================================
 celery.concurrency.prefork
=============================================================

.. contents::
    :local:
.. currentmodule:: celery.concurrency.prefork

.. automodule:: celery.concurrency.prefork
    :members:
    :undoc-members:
