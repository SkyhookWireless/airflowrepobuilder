The following command retrieves a list of SNS topics::

  aws sns list-topics

Output::

  {
      "Topics": [
          {
              "TopicArn": "arn:aws:sns:us-west-2:0123456789012:my-topic"
          }
      ]
  }
